from flask import Flask, request, jsonify, redirect, render_template
import keyboard
import os,time
import subprocess

app = Flask(__name__)



@app.route('/')
def index():
    return "<meta http-equiv=\"Refresh\" content=\"0; url='/dashboard'\" /><script> window.location.href = '/dashboard'; </script>POGPOG"

@app.route('/deur/<status>', methods =['GET'])
def deur(status):
    print(status)
    if status.upper() == "OPEN":
        keyboard.press_and_release('Volume Mute')
        keyboard.press_and_release('Ctrl + Alt + `')
        

        subprocess.call(["C:\\Users\\jorik\\AppData\\Local\\Programs\\Opera GX\\launcher.exe"])

        time.sleep(1)
        keyboard.press_and_release('F11')

        return jsonify({"sucess": True})
    elif status.upper() == "CLOSE":
        return jsonify({"sucess": True})
    else:
        return jsonify({"sucess": False, "error": "Invalid status"})
    
@app.route("/shutdown", methods=['GET'])
def shutdown():
    # check if the parameter "KEY" is correct
    if request.args.get('KEY') == "1234":    
        exit()
    elif request.args.get('KEY') == "REALSHUTDOWN":
        os.system("shutdown /s /t 2")
        return jsonify({"sucess": True})
    else:
        return jsonify({"sucess": False, "error": "Invalid key"})
    
@app.route("/msg")
def msg():
    try:
        msg = request.args.get("bericht")
        print(msg)
        os.system("msg * " + msg)
        return jsonify({"sucess": True})
    except:
        return jsonify({"sucess": False, "error": "Invalid message; Usage: /msg?bericht=YOURMESSAGE"})

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=True)